import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LiveControl from "@/pages/LiveControl";
import { WhatIf } from "@/pages/WhatIf";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LiveControl />} />
        <Route path="/what-if" element={<WhatIf />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/simulation" element={<div className="p-10 text-2xl">Simulation Mode (Legacy)</div>} />
        <Route path="/analytics" element={<div className="p-10 text-2xl">Analytics Dashboard (Coming Soon)</div>} />
      </Routes>
    </Router>
  );
}

export default App;
